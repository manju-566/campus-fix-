# CampusFix — Antigravity Prompt Pack

This folder contains six sequential prompts for building **CampusFix — Smart Campus Issue Resolver**, a hackathon prototype.

## Suggested order

1. `Prompt_1_Frontend_Foundation.txt` — React/Vite foundation, visual design, and dashboard layouts.
2. `Prompt_2_Frontend_Interactions.txt` — complete frontend flows and demo interactions.
3. `Prompt_3_Backend_Authentication.txt` — Express/SQLite foundation, authentication, and centralized permissions.
4. `Prompt_4_Reports_and_Grouping.txt` — secure report APIs, privacy-safe grouping suggestions, and student/staff frontend integration.
5. `Prompt_5_Management_Workflow.txt` — management queue, deterministic priority rules, assignments, history, overdue handling, and notifications.
6. `Prompt_6_Integration_and_QA.txt` — integration, security review, testing, accessibility, and demo readiness.

## How to use

Paste one prompt at a time into Antigravity, in order. Wait for the stage to finish, inspect the changes, and run the commands it reports before submitting the next prompt. Keep a backup or use version control before each stage. If a stage has errors or unfinished features, fix those before moving on; later prompts assume the earlier stages were implemented.

These prompts aim for a hackathon MVP, not a production-ready system. Antigravity may need additional repair prompts depending on its token/context limits and the actual project state. Do not put real passwords, API keys, or private user data into prompt files or source control. Use development-only test accounts and a disposable test database.

## Role naming

The role label is **Vice Principal** throughout this prompt pack, with the backend role slug `vice_principal`. Keep this naming consistent in the implementation.
